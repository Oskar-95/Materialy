﻿- krokové motory mají 4 nebo 6 vývodů, TMC22XX mají 4 vývody - vzít správný motor 
- motory mohou mít různý odpor vinutí (od 3R do 40R), přitom jeden motor musí mít na obou vinutích stejný odpor, jinak je v něm chyba/porucha 

Komunikace driveru: 

z ESP32: 
	a) nastavuju rychlost 
	b) nastavuju polohu (STEP-DIR)

a) posílá pulz na ID? pin vždy pod 4x256 mikrokrocích, tj. 4 krocích
b) posílá pulz každý mikrokrok 
c) pošlu příkaz přes UART a v odpovědi dostanu aktuální hodnotu natočení ( od 0 do 1023) v mikrokrocích -> musím to číst pravidelně, 
abych se při "přetečení" neztratil 



https://platformio.org/lib/show/5513/TMCStepper
---------------------------------------------
Jirka: 
doporučený postup: napřed rozjet RBCGUI, potom UART, potom to ostatní 
- nastavovat rychlost přes UART (přes UART nejde nastavit dráha, dráha jde nastavit přes STEP/DIR) 
- číst PWM z pinu INDEX - SW enkodér (a koncák, když se to naprogramuje) 
- enable pin - vypíná silovou část driveru 

Programování - inicializace: 

- reset pin - po resetu ESP se někdy na TMC2209 objevují prapodivné stavy, proto se po začátku programu 
preventivně provede restart TMC2209 
p. 16: The UART  line must be  logic high during  idle state.  Therefore,  the power down  function  cannot be 
assigned  by  the  pin  PDN_UART  in  between  of  transmissions.  In  an  application  using  the  UART 
interface, set  the desired power down  function by  register access and set  pdn_disable  in GCONF  to 
disable the pin function. 
pdn_disable  
0:  PDN_UART controls standstill current reduction 
1:  PDN_UART  input  function  disabled.  Set  this  bit, when using the UART interface! (p. 20) 


PDN_UART  Non-inverted data input and output. I/O with Schmitt Trigger and VCC_IO level. (p. 17)

- Reset default: All registers become reset to 0 upon power up, unless otherwise noted. 
- automatické nastavování driveru pro optimální chod (AT - auto tuning - p. 35-36) musí být provedeno po 
resetu motorů nebo po změně napájecího napětí motorů -> součást inicializace 

Programování - běh programu:  

- Add 0x80 to the address Addr for write accesses!  (p. 19)
- Interface  transmission  counter.  This  register  becomes incremented with each successful UART interface write access. (p. 20)
- SGTHRS Detection  threshold  for  stall.  The  StallGuard  value  SG_RESULT becomes compared to the double of this threshold.  
  A stall is signaled with  SG_RESULT ≤ SGTHRS*2 (p.26) 
- MSCNT Microstep  counter.  Indicates  actual  position in the microstep table for CUR_A. (p. 28) 

Pozn: při HW nastavené adrese na driveru (MS1_AD0, MS1_AD1) bude v módu řízení STEP/DIR nastavená jiná 
velikost mikrokroku -> musí se ošetřit v SW (str. 9) 
mstep_reg_select 
0:  Microstep resolution selected by pins MS1, MS2 
1:  Microstep resolution selected by MSTEP register (p. 20) 

Stand still option when motor current setting is zero (I_HOLD=0). (p. 32) 
%00:   Normal operation 
%01:   Freewheeling 

stst  standstill indicator  This  flag  indicates motor  stand  still  in  each  operation mode. This occurs 2^20 clocks after the last step pulse. (p.34)
stealth  StealthChop indicator  1: Driver operates in StealthChop mode 
				0: Driver operates in SpreadCycle mode 
ot  overtemperature flag 
otpw  overtemperature prewarning flag  (p.34, detailed in p. 65) 

Quick Configuration Guide - p. 67

Layout Considerations - p. 78

Pozn: veškeré programování driveru je čtení z registrů a zápis do registrů 

------------------------------------------------------------
# TMC2208
Proud: 1,4A/2A max
Napětí motoru: 4,75V - 36V / 256 krokov
Mikro-krokování: 2/4/8/16 HW, až 256 SW

Výpočet proudu motoru: Irms = Uref / 1,41

https://github.com/bigtreetech/BIGTREETECH-TMC2208-V3.0

https://pl.aliexpress.com/item/33047241001.html?spm=2114.12010612.8148356.1.1e7e56fbY9E0ZC

https://github.com/teemuatlut/TMCStepper/issues/35

# TMC2209
2 A RMS, 2,8 A peak 
max 29 V
https://github.com/bigtreetech/BIGTREETECH-TMC2209-V1.2
https://www.na3d.cz/p/2723/tmc2209-tmc-2209-tichy-ovladac-krokoveho-motoru - nedostupne
https://www.levna3dtiskarna.cz/motorovy-driver-tmc-2209/

piny index, diag a vref jsou popsány v TMC2209-V1.2-board manual.pdf na str. 4


Jeden poznatek k těm 2209, které mi včera konečně dorazily. 
Oproti TMC 2208 jdou na Marlinu 1.1.9 používat i na extruderu ve standalone modu. 
Což byl rozšířený problém u 2208, muselo se to většinou řešit pomocí UART modu a případně dalšího nastavení,
protože ve standalone(stealthchop) se extruder vypínal během tisku.

# TMC2225

https://www.na3d.cz/p/3223/ovladac-krokoveho-motoru-tmc-2225-v10

